<?php 
function echoi(){
	
}